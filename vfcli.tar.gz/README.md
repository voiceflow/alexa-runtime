[![Quality Gate Status](https://sonarcloud.io/api/project_badges/measure?project=voiceflow_vfcli&metric=alert_status&token=604906a8d347e5241c0d1463b8060a4636ebcecc)](https://sonarcloud.io/dashboard?id=voiceflow_vfcli)
[![Bugs](https://sonarcloud.io/api/project_badges/measure?project=voiceflow_vfcli&metric=bugs&token=604906a8d347e5241c0d1463b8060a4636ebcecc)](https://sonarcloud.io/dashboard?id=voiceflow_vfcli)
[![Code Smells](https://sonarcloud.io/api/project_badges/measure?project=voiceflow_vfcli&metric=code_smells&token=604906a8d347e5241c0d1463b8060a4636ebcecc)](https://sonarcloud.io/dashboard?id=voiceflow_vfcli)
[![Duplicated Lines (%)](https://sonarcloud.io/api/project_badges/measure?project=voiceflow_vfcli&metric=duplicated_lines_density&token=604906a8d347e5241c0d1463b8060a4636ebcecc)](https://sonarcloud.io/dashboard?id=voiceflow_vfcli)
[![Lines of Code](https://sonarcloud.io/api/project_badges/measure?project=voiceflow_vfcli&metric=ncloc&token=604906a8d347e5241c0d1463b8060a4636ebcecc)](https://sonarcloud.io/dashboard?id=voiceflow_vfcli)
[![Maintainability Rating](https://sonarcloud.io/api/project_badges/measure?project=voiceflow_vfcli&metric=sqale_rating&token=604906a8d347e5241c0d1463b8060a4636ebcecc)](https://sonarcloud.io/dashboard?id=voiceflow_vfcli)
[![Reliability Rating](https://sonarcloud.io/api/project_badges/measure?project=voiceflow_vfcli&metric=reliability_rating&token=604906a8d347e5241c0d1463b8060a4636ebcecc)](https://sonarcloud.io/dashboard?id=voiceflow_vfcli)
[![Security Rating](https://sonarcloud.io/api/project_badges/measure?project=voiceflow_vfcli&metric=security_rating&token=604906a8d347e5241c0d1463b8060a4636ebcecc)](https://sonarcloud.io/dashboard?id=voiceflow_vfcli)
[![Technical Debt](https://sonarcloud.io/api/project_badges/measure?project=voiceflow_vfcli&metric=sqale_index&token=604906a8d347e5241c0d1463b8060a4636ebcecc)](https://sonarcloud.io/dashboard?id=voiceflow_vfcli)
[![Vulnerabilities](https://sonarcloud.io/api/project_badges/measure?project=voiceflow_vfcli&metric=vulnerabilities&token=604906a8d347e5241c0d1463b8060a4636ebcecc)](https://sonarcloud.io/dashboard?id=voiceflow_vfcli)

# vfcli
Voiceflow CLI tool for all development activities
